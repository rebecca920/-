"""mysite_login URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
#from django.contrib import admin
#from django.conf.urls import include
#from django.urls import path
#from login import views

#urlpatterns = [
   # path('admin/', admin.site.urls),
   # path('index/',views.index),
    #path('login/',views.login),
   # path('register/',views.register),
   # path('logout/',views.logout),
    #path('captcha', include('captcha.urls')) 
#]


from django.conf.urls import url

from django.conf.urls import include

from django.contrib import admin

from login import views

 

urlpatterns = [

    url(r'^admin/', admin.site.urls),

    url(r'^index/', views.index),

    url(r'^login/', views.login),

    url(r'^register/', views.register),

    url(r'^logout/', views.logout),

    url(r'^call/', views.call),
    url(r'^table/', views.table1),
    url(r'^table1/', views.table1),
    url(r'^table2/', views.table2),
    url(r'^table3/', views.table3),
    url(r'^xiangqing1/', views.xiangqing1),
    url(r'^xiangqing/', views.xiangqing1),

    url(r'^bus286/', views.bus286),  
    
    url(r'^base/', views.base),
    
    url(r'^bus148/', views.bus148), 
    
    url(r'^bus332/', views.bus332),
    
    url(r'^bus382/', views.bus382),
    
    url(r'^busB2C/', views.busB2C),
    
    url(r'^xianlu/', views.xianlu),
    url(r'^xl/xl11/', views.xl11),
    url(r'^xl/xl12/', views.xl12),
    url(r'^xl/xl13/', views.xl13),
    url(r'^xl/xl21/', views.xl21),
    url(r'^xl/xl22/', views.xl22),
    url(r'^xl/xl23/', views.xl23),
    url(r'^base/', views.base),

     
     
    url(r'^captcha', include('captcha.urls')) # 增加这一行  
    
   
 
]